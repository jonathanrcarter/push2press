<?php

$action = $_GET["action"];

include_once(dirname(__FILE__)."/../../../wp-config.php");



if ($action == "make") {
	echo dirname(__FILE__);
	
	$D = "$";

	$err = false;
	if (file_exists(dirname(__FILE__)."/p2p")) {
		echo "p2p is already installed";
//		echo "<a href='/wp-admin/admin.php?page=push2press/p2p/install.php'>p2p/install.php</a>";
		echo "<a href='/wp-admin/admin.php?page=push2press/admin.php&_action=install.php'>p2p/install.php</a>";
	} else {

		mkdir(dirname(__FILE__)."/p2p");
		$h = "";
		$h = $h . "<?php\n";
		$h = $h . $D . "dbhost='localhost';\n";
		$h = $h . $D . "username='".DB_USER."';\n";
		$h = $h . $D . "password='".DB_PASSWORD."';\n";
		$h = $h . $D . "database='".DB_NAME."';\n";
		$h = $h . $D . "lang='en';\n";
		$h = $h . $D . "hosted='wordpress';\n";
		$h = $h . "?>\n";

		file_put_contents(dirname(__FILE__)."/p2p/local_config.php", $h);

		$download = file_put_contents(dirname(__FILE__)."/p2p/install.php", file_get_contents("https://raw.github.com/jonathanrcarter/push2press/master/p2p/install.php"));
	}
	
	echo ("<script>document.location.href='/wp-admin/admin.php?page=push2press/admin.php&_action=install.php';</script>"); 

	echo "<a href='/wp-admin/admin.php?page=push2press/admin.php&_action=install.php'>p2p/install.php</a>";
	
//	echo "<a href='/wp-admin/admin.php?page=push2press/p2p/install.php'>p2p/install.php</a>";
	
}

if ($action == "uninstall") {
	if (file_exists(dirname(__FILE__)."/p2p")) {
		rmdir(dirname(__FILE__)."/p2p");
	}

}

echo "
<style>
.p2p {
	line-height:2.5em;
	padding:16px;
}
</style>";

echo "<div class='p2p'>";
echo "<div><img src='http://www.push2press.com/p2p/images/application-logo.png'></div>";
echo "<li><a href='/wp-admin/admin.php?page=push2press/make.php&action=make'>Install Push2Press</a></li>";
echo "<li><a href='/wp-admin/admin.php?page=push2press/make.php&action=uninstall'>UN-Install Push2Press</a></li>";
echo "</div>";

?>