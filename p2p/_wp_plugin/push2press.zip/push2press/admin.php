<?php

$_action = $_GET["_action"];


if ($_action == "install.php") {
	echo "
	<script>
	function p2p_admin() {
		document.location.href='/wp-admin/admin.php?page=push2press/admin.php';
	}
	</script>
	";
	echo "<iframe src='/wp-content/plugins/push2press/p2p/install.php?_frame=y' style='width:100%;height:800px;'></iframe>";
//	require("p2p/install.php");

} else if ($_action == "make.php") {

	require("make.php");

} else if (file_exists(dirname(__FILE__)."/p2p")) {

	echo "<iframe src='/wp-content/plugins/push2press/p2p/api.php' style='width:100%;height:800px;'></iframe>";

} else {

	require("make.php");

}




?>