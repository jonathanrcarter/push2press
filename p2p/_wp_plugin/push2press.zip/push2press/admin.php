<?php

if (file_exists(dirname(__FILE__)."/p2p")) {
	echo "<iframe src='/wp-content/plugins/push2press/p2p/api.php' style='width:100%;height:800px;'></iframe>";
} else {
	require("make.php");
}




?>