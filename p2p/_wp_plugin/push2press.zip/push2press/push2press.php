<?php
   /*
   Plugin Name: push2press
   Plugin URI: http://awesomelypopularplugin.com
   Description: A plugin that records post views and contains functions to easily list posts by popularity
   Version: 1.0
   Author: Mr. Awesome
   Author URI: http://mayawesomefillyourbelly.com
   License: GPL2
   */

if(is_admin()){	
	add_action('admin_menu', 'register_p2p_menu_page');
	
	function register_p2p_menu_page() {
	   add_menu_page('Push 2 Press', 'Push2Press', 'add_users', 'push2press/admin.php', '',   plugins_url('push2press/menu.png'), 97);
	}

}



?>