<?php
   /*
   Plugin Name: push2press
   Plugin URI: http://www.push2press.com
   Description: Push2Press is an Open Source Native App CMS that accelerates the development of iPhone and Android apps that have built-in Push Notification functionality
   Version: 1.0
   Author: Glimworm IT BV
   Author URI: http://www.push2press.com
   License: GPL2
   */

if(is_admin()){	
	add_action('admin_menu', 'register_p2p_menu_page');
	
	function register_p2p_menu_page() {
	   add_menu_page('Push 2 Press', 'Push2Press', 'add_users', 'push2press/admin.php', '',   plugins_url('push2press/menu.png'), 97);
	   add_submenu_page( "push2press/admin.php", "push2press Installation", "Installation", 'add_users', "push2press/make.php");
	   
	}

}



?>